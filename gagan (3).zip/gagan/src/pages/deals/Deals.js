import React from 'react'
import Navbar from '../../components/navbar/Navbar'
import './Deals.css'
import Footer from '../../components/footer/Footer'
// import Order from '../../components/foodorder/Order'
import Image from '../../components/dividingimage/Image'
import Main from '../../components/main/Main'

function Deals() {
    return (
      <div>
        <div className='section__1'>
          <Navbar />
          <Main />
        </div>
        <div className='dividing__img'>
          <Image />
        </div>
        <div className='section__2'>
          <Deals />
        </div>
        <Footer />
      </div>
    )
  }
  
  export default Deals