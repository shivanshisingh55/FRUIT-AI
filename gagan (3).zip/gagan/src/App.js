import React from 'react'
import './App.css'
import { Routes, Route } from "react-router-dom";
import Home from './pages/home/Home';
import Menu from './pages/menu/Menu';
import ContactUs from './pages/contactus/ContactUs';
import Story from './pages/ourstory/Story';
import Login from './pages/login/Login';
import Deals from './pages/deals/Deals';
function App() {
  return (
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/menu' element={<Menu />} />
      <Route path='/story' element={<Story />} />
      <Route path='/deals' element={<Deals /> }/>
      <Route path='/contact' element={<ContactUs />} />
      <Route path='/login' element={<Login />} />
    </Routes>
  )
}

export default App
